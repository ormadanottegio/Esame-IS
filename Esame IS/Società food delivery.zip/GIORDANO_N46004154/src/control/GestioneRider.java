package control;
import java.util.ArrayList;
import entity.Rider;

public class GestioneRider {
	private static GestioneRider uniqueInstance = new GestioneRider();	//	Singleton
	private GestioneRider() {}
	public static GestioneRider instance() { return uniqueInstance; }
	
	private ArrayList<Rider> listaRider = new ArrayList<Rider>();

	public void aggiungiRider(String nome, String cognome, String telefono) {
		listaRider.add(new Rider(nome, cognome, telefono));
	}
}
