package control;
import entity.*;
import java.util.ArrayList;

public class GestioneRistoranti {
	private static GestioneRistoranti uniqueInstance = new GestioneRistoranti();	//	Singleton
	private GestioneRistoranti() {}
	public static GestioneRistoranti instance() { return uniqueInstance; }
	
	private ArrayList<Ristoratore> listaRistoratori = new ArrayList<Ristoratore>();
	private ArrayList<Ristorante> listaRistoranti = new ArrayList<Ristorante>();
	
	public Ristoratore aggiungiRistoratore(String nome, String cognome, String nomeRistorante,
			String telefonoRistorante, String emailRistorante, String citt�Ristorante,
			String viaRistorante, Integer civicoRistorante) {
		
		Ristorante r = new Ristorante(nomeRistorante, telefonoRistorante, emailRistorante,
				citt�Ristorante, viaRistorante, civicoRistorante);
		listaRistoranti.add(r);
		Ristoratore ristoratore = new Ristoratore(nome, cognome, r);
		listaRistoratori.add(ristoratore);
		return ristoratore;
	}
	
	public void aggiungiPietanza(Ristorante r, String nome, String descrizione, Double prezzo) {
		r.aggiungiPietanza(nome, descrizione, prezzo);
	}
	
	public boolean rimuoviPietanza(Ristorante r, String nome) {
		return r.rimuoviPietanza(nome);
	}
	
	public boolean modificaNomePietanza(Ristorante r, String nome, String nuovoNome) {
		return r.modificaNomePietanza(nome, nuovoNome);
	}
	
	public boolean modificaDescPietanza(Ristorante r, String nome, String nuovoDesc) {
		return r.modificaDescPietanza(nome, nuovoDesc);
	}
	
	public boolean modificaPrezzoPietanza(Ristorante r, String nome, Double nuovoPrezzo) {
		return r.modificaPrezzoPietanza(nome, nuovoPrezzo);
	}
	
	public ArrayList<Ristorante> ricercaRistoranti(String citt�, String via, Integer civico) {
		ArrayList<Ristorante> result = new ArrayList<Ristorante>();
		for (Ristorante r : listaRistoranti)
			if (r.getCitt�() == citt� && r.getVia() == via && r.getCivico() == civico)
				result.add(r);
		return result;
	}
	
	public ArrayList<Pietanza> visualizzaPietanze(Ristorante ristorante) {
		return ristorante.getPietanze();
	}
	
	public void rimuoviRistoranti() {
		listaRistoranti.clear();
		listaRistoratori.clear();
	}
}
