package control;
import entity.Ristorante;
import entity.StatoOrdine;
import entity.Ordine;
import boundary.BRistorante;
import boundary.BRider;
import java.util.HashMap;

public class GestioneNotifiche {
	private static GestioneNotifiche uniqueInstance = new GestioneNotifiche();
	private GestioneNotifiche() {}
	public static GestioneNotifiche instance() { return uniqueInstance; }
	
	private HashMap<Ristorante, BRistorante> iscrittiBRistorante = new HashMap<Ristorante, BRistorante>();
	private HashMap<Ristorante, BRider> iscrittiBRider = new HashMap<Ristorante, BRider>();
	
	public void iscriviBRistorante(Ristorante ristorante, BRistorante bRistorante) {
		iscrittiBRistorante.put(ristorante, bRistorante);
	}
	
	public void iscriviBRider(Ristorante ristorante, BRider bRider) {
		iscrittiBRider.put(ristorante, bRider);
	}
	
	public void notifica(Ristorante ristorante, Ordine ordine) {
		if (ordine.getStato() == StatoOrdine.CONFERMATO)
			iscrittiBRistorante.get(ristorante).update(ordine);
		else if (ordine.getStato() == StatoOrdine.PRONTO)
			iscrittiBRider.get(ristorante).update(ordine);
	}
	
	public void cambiaStatoOrdine(Ordine ordine, StatoOrdine stato) {
		ordine.setStato(stato);
	}
}
