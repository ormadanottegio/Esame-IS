package control;

import java.util.ArrayList;

import entity.Cliente;

public class GestioneClienti {
	private static GestioneClienti uniqueInstance = new GestioneClienti();	//	Singleton
	private GestioneClienti() {}
	public static GestioneClienti instance() { return uniqueInstance; }
	
	private ArrayList<Cliente> listaClienti = new ArrayList<Cliente>();

	public Cliente registraCliente(String nome, String cognome, String telefono,
			String idCarta, Double saldoCarta) {
		Cliente c = new Cliente(nome, cognome, telefono, idCarta, saldoCarta);
		listaClienti.add(c);
		return c;
	}
}
