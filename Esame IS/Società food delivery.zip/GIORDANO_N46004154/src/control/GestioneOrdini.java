package control;
import java.util.ArrayList;
import java.util.Collections;
import java.time.LocalDate;
import java.time.Month;

//import java.time.Month;
import entity.*;

public class GestioneOrdini {
	private static GestioneOrdini uniqueInstance = new GestioneOrdini();	//	Singleton
	private GestioneOrdini() {}
	public static GestioneOrdini instance() { return uniqueInstance; }
	
	private ArrayList<Ordine> listaOrdini = new ArrayList<Ordine>();
	private OrdineTemp ordineTemp = new OrdineTemp();

	//	Fino alla conferma o all'annullamento, i dati inseriti dal cliente
	//	sono salvati in questa classe
	private class OrdineTemp {
		private ArrayList<Pietanza> pietanzeTemp = new ArrayList<Pietanza>();
		private ArrayList<Integer> quantit�Temp = new ArrayList<Integer>();
		private Ristorante ristorante;
	}
	

	//	Questi tre metodi riempiono e svuotano i campi di ordineTemp
	public void selezionaRistorante(Ristorante r) {
		ordineTemp.ristorante = r;
	}
	public void selezionaPietanze(Pietanza[] pArr) {
		Collections.addAll(ordineTemp.pietanzeTemp, pArr);
	}
	public void selezionaQuantit�(Integer[] iArr) {
		Collections.addAll(ordineTemp.quantit�Temp, iArr);
	}
	public void svuotaTemp() {
		ordineTemp.pietanzeTemp.clear();
		ordineTemp.quantit�Temp.clear();
		ordineTemp.ristorante = null;
	}
	
	
	public void confermaOrdine(Cliente cliente) {
		Ordine o = new Ordine(ordineTemp.ristorante, ordineTemp.pietanzeTemp,
				ordineTemp.quantit�Temp);
		
		cliente.getCarta().addToSaldo(-o.getPrezzo());
		
		listaOrdini.add(o);
		
		o.setStato(StatoOrdine.CONFERMATO);
	}
	
	public ArrayList<Ordine> visualizzaOrdini(String nomeRistorante, Integer mese) {
		ArrayList<Ordine> result = new ArrayList<Ordine>();

		for (Ordine o : listaOrdini)
			if ( (nomeRistorante == null) || (o.getRistorante().getNome() == nomeRistorante)
				&& (mese == null) || (o.getData().getMonthValue() == mese) )
				result.add(o);
		return result;
	}
	
	public void rimuoviOrdini() {
		listaOrdini.clear();
	}
	
	public void aggiungiOrdine(Ordine ordine) {	//	Per test
		listaOrdini.add(ordine);
	}
}
