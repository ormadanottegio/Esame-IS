package test;

import static org.junit.Assert.*;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import control.GestioneOrdini;
import control.GestioneRistoranti;
import entity.Ordine;
import entity.Pietanza;
import entity.Ristorante;


@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class GestioneOrdiniTest {
	
	@BeforeClass
	public static void setUpBeforeClass() {}
	
	@Before
	public void setUp() {}
	@After
	public void tearDown() {
		GestioneOrdini.instance().rimuoviOrdini();
		GestioneRistoranti.instance().rimuoviRistoranti();
	}

	@Test
	public void test01() {
		
		Ristorante r = new Ristorante("daLuca", "", "", "", "", 0);
		LocalDate oData = LocalDate.of(2020, Month.MARCH, 1);
		Ordine o = new Ordine(r, new ArrayList<Pietanza>(), new ArrayList<Integer>(), oData);
		
		GestioneRistoranti.instance().aggiungiRistoratore("nomeRistoratore1", "cognomeRistoratore1",
				r.getNome(), r.getTelefono(), r.getEmail(), r.getCitt�(), r.getVia(), r.getCivico());
		
		GestioneOrdini.instance().aggiungiOrdine(o);
		
		
		ArrayList<Ordine> result = GestioneOrdini.instance().visualizzaOrdini("daLuca", 2);
		assertEquals(0, result.size());
	}
	
	@Test
	public void test02() {
		
		Ristorante r = new Ristorante("daLuca", "", "", "", "", 0);
		LocalDate oData = LocalDate.of(2020, Month.MARCH, 1);
		Ordine o = new Ordine(r, new ArrayList<Pietanza>(), new ArrayList<Integer>(), oData);
		
		GestioneRistoranti.instance().aggiungiRistoratore("nomeRistoratore1", "cognomeRistoratore1",
				r.getNome(), r.getTelefono(), r.getEmail(), r.getCitt�(), r.getVia(), r.getCivico());
		
		GestioneOrdini.instance().aggiungiOrdine(o);
		
		
		ArrayList<Ordine> result = GestioneOrdini.instance().visualizzaOrdini("daLuca", 3);
		assertEquals(1, result.size());
	}
	
	@Test
	public void test03() {
		
		Ristorante r = new Ristorante("daLuca", "", "", "", "", 0);
		LocalDate oData = LocalDate.of(2020, Month.MARCH, 1);
		Ordine o = new Ordine(r, new ArrayList<Pietanza>(), new ArrayList<Integer>(), oData);
		
		GestioneRistoranti.instance().aggiungiRistoratore("nomeRistoratore1", "cognomeRistoratore1",
				r.getNome(), r.getTelefono(), r.getEmail(), r.getCitt�(), r.getVia(), r.getCivico());
		
		GestioneOrdini.instance().aggiungiOrdine(o);
		
		
		ArrayList<Ordine> result = GestioneOrdini.instance().visualizzaOrdini(null, 2);
		assertEquals(0, result.size());
	}
	
	
	@Test
	public void test04() {
		
		Ristorante r = new Ristorante("daLuca", "", "", "", "", 0);
		LocalDate oData = LocalDate.of(2020, Month.MARCH, 1);
		Ordine o = new Ordine(r, new ArrayList<Pietanza>(), new ArrayList<Integer>(), oData);
		
		GestioneRistoranti.instance().aggiungiRistoratore("nomeRistoratore1", "cognomeRistoratore1",
				r.getNome(), r.getTelefono(), r.getEmail(), r.getCitt�(), r.getVia(), r.getCivico());
		
		GestioneOrdini.instance().aggiungiOrdine(o);
		
		
		ArrayList<Ordine> result = GestioneOrdini.instance().visualizzaOrdini(null, 3);
		assertEquals(1, result.size());
	}
	
	@Test
	public void test05() {
		
		Ristorante r = new Ristorante("daLuca", "", "", "", "", 0);
		LocalDate oData = LocalDate.of(2020, Month.MARCH, 1);
		Ordine o = new Ordine(r, new ArrayList<Pietanza>(), new ArrayList<Integer>(), oData);
		
		GestioneRistoranti.instance().aggiungiRistoratore("nomeRistoratore1", "cognomeRistoratore1",
				r.getNome(), r.getTelefono(), r.getEmail(), r.getCitt�(), r.getVia(), r.getCivico());
		
		GestioneOrdini.instance().aggiungiOrdine(o);
		
		ArrayList<Ordine> result = GestioneOrdini.instance().visualizzaOrdini("daLuca", null);
		assertEquals(1, result.size());
	}
	
	
	
	@Test
	public void test06() {
		
		Ristorante r = new Ristorante("daLuca", "", "", "", "", 0);
		LocalDate oData = LocalDate.of(2020, Month.MARCH, 1);
		Ordine o = new Ordine(r, new ArrayList<Pietanza>(), new ArrayList<Integer>(), oData);
		
		GestioneRistoranti.instance().aggiungiRistoratore("nomeRistoratore1", "cognomeRistoratore1",
				r.getNome(), r.getTelefono(), r.getEmail(), r.getCitt�(), r.getVia(), r.getCivico());
		
		GestioneOrdini.instance().aggiungiOrdine(o);
		
		
		ArrayList<Ordine> result = GestioneOrdini.instance().visualizzaOrdini(null, null);
		assertEquals(1, result.size());
	}
	
	@Test
	public void test07() {
		
		Ristorante r = new Ristorante("daLuca", "", "", "", "", 0);
		LocalDate oData = LocalDate.of(2020, Month.MARCH, 1);
		LocalDate o2Data = LocalDate.of(2020, Month.APRIL, 1);
		Ordine o = new Ordine(r, new ArrayList<Pietanza>(), new ArrayList<Integer>(), oData);
		Ordine o2 = new Ordine(r, new ArrayList<Pietanza>(), new ArrayList<Integer>(), o2Data);
		
		GestioneRistoranti.instance().aggiungiRistoratore("nomeRistoratore1", "cognomeRistoratore1",
				r.getNome(), r.getTelefono(), r.getEmail(), r.getCitt�(), r.getVia(), r.getCivico());
		
		GestioneOrdini.instance().aggiungiOrdine(o);
		GestioneOrdini.instance().aggiungiOrdine(o2);
		
		
		ArrayList<Ordine> result = GestioneOrdini.instance().visualizzaOrdini("daLuca", 2);
		assertEquals(0, result.size());
		
	}
	
	@Test
	public void test08() {
		
		Ristorante r = new Ristorante("daLuca", "", "", "", "", 0);
		LocalDate oData = LocalDate.of(2020, Month.MARCH, 1);
		LocalDate o2Data = LocalDate.of(2020, Month.APRIL, 1);
		Ordine o = new Ordine(r, new ArrayList<Pietanza>(), new ArrayList<Integer>(), oData);
		Ordine o2 = new Ordine(r, new ArrayList<Pietanza>(), new ArrayList<Integer>(), o2Data);
		
		GestioneRistoranti.instance().aggiungiRistoratore("nomeRistoratore1", "cognomeRistoratore1",
				r.getNome(), r.getTelefono(), r.getEmail(), r.getCitt�(), r.getVia(), r.getCivico());
		
		GestioneOrdini.instance().aggiungiOrdine(o);
		GestioneOrdini.instance().aggiungiOrdine(o2);
		
		
		ArrayList<Ordine> result = GestioneOrdini.instance().visualizzaOrdini("daLuca", 3);
		assertEquals(1, result.size());
		
	}
	
	@Test
	public void test09() {
		
		Ristorante r = new Ristorante("daLuca", "", "", "", "", 0);
		LocalDate oData = LocalDate.of(2020, Month.MARCH, 1);
		LocalDate o2Data = LocalDate.of(2020, Month.APRIL, 1);
		Ordine o = new Ordine(r, new ArrayList<Pietanza>(), new ArrayList<Integer>(), oData);
		Ordine o2 = new Ordine(r, new ArrayList<Pietanza>(), new ArrayList<Integer>(), o2Data);
		
		GestioneRistoranti.instance().aggiungiRistoratore("nomeRistoratore1", "cognomeRistoratore1",
				r.getNome(), r.getTelefono(), r.getEmail(), r.getCitt�(), r.getVia(), r.getCivico());
		
		GestioneOrdini.instance().aggiungiOrdine(o);
		GestioneOrdini.instance().aggiungiOrdine(o2);
		
		
		ArrayList<Ordine> result = GestioneOrdini.instance().visualizzaOrdini(null, 2);
		assertEquals(0, result.size());
		
	}
	
	@Test
	public void test10() {
		
		Ristorante r = new Ristorante("daLuca", "", "", "", "", 0);
		LocalDate oData = LocalDate.of(2020, Month.MARCH, 1);
		LocalDate o2Data = LocalDate.of(2020, Month.APRIL, 1);
		Ordine o = new Ordine(r, new ArrayList<Pietanza>(), new ArrayList<Integer>(), oData);
		Ordine o2 = new Ordine(r, new ArrayList<Pietanza>(), new ArrayList<Integer>(), o2Data);
		
		GestioneRistoranti.instance().aggiungiRistoratore("nomeRistoratore1", "cognomeRistoratore1",
				r.getNome(), r.getTelefono(), r.getEmail(), r.getCitt�(), r.getVia(), r.getCivico());
		
		GestioneOrdini.instance().aggiungiOrdine(o);
		GestioneOrdini.instance().aggiungiOrdine(o2);
		
		
		ArrayList<Ordine> result = GestioneOrdini.instance().visualizzaOrdini(null, 3);
		assertEquals(1, result.size());
		
	}
	
	@Test
	public void test11() {
		
		Ristorante r = new Ristorante("daLuca", "", "", "", "", 0);
		
		GestioneRistoranti.instance().aggiungiRistoratore("nomeRistoratore1", "cognomeRistoratore1",
				r.getNome(), r.getTelefono(), r.getEmail(), r.getCitt�(), r.getVia(), r.getCivico());
		
		
		ArrayList<Ordine> result = GestioneOrdini.instance().visualizzaOrdini("daLuca", 2);
		assertEquals(0, result.size());
		
	}
	
	@Test
	public void test12() {		
		
		ArrayList<Ordine> result = GestioneOrdini.instance().visualizzaOrdini("daLuca", 2);
		assertEquals(0, result.size());
		
	}
	
	@Test
	public void test13() {
		
		Ristorante r = new Ristorante("daLuca", "", "", "", "", 0);
		LocalDate oData = LocalDate.of(2020, Month.MARCH, 1);
		Ordine o = new Ordine(r, new ArrayList<Pietanza>(), new ArrayList<Integer>(), oData);
		
		GestioneRistoranti.instance().aggiungiRistoratore("nomeRistoratore1", "cognomeRistoratore1",
				r.getNome(), r.getTelefono(), r.getEmail(), r.getCitt�(), r.getVia(), r.getCivico());
		
		GestioneOrdini.instance().aggiungiOrdine(o);
		
		ArrayList<Ordine> result = GestioneOrdini.instance().visualizzaOrdini("daMario", 2);
		assertEquals(0, result.size());
		
	}
	
	@Test
	public void test14() {
		
		Ristorante r = new Ristorante("daLuca", "", "", "", "", 0);
		Ristorante r2 = new Ristorante("daLuca", "", "", "", "", 0);
		LocalDate oData = LocalDate.of(2020, Month.MARCH, 1);
		Ordine o = new Ordine(r, new ArrayList<Pietanza>(), new ArrayList<Integer>(), oData);
		Ordine o3 = new Ordine(r2, new ArrayList<Pietanza>(), new ArrayList<Integer>(), oData);
		
		GestioneRistoranti.instance().aggiungiRistoratore("nomeRistoratore1", "cognomeRistoratore1",
				r.getNome(), r.getTelefono(), r.getEmail(), r.getCitt�(), r.getVia(), r.getCivico());
		GestioneRistoranti.instance().aggiungiRistoratore("nomeRistoratore2", "cognomeRistoratore2",
				r2.getNome(), r2.getTelefono(), r2.getEmail(), r2.getCitt�(), r2.getVia(), r2.getCivico());
		
		GestioneOrdini.instance().aggiungiOrdine(o);
		GestioneOrdini.instance().aggiungiOrdine(o3);
		
		ArrayList<Ordine> result = GestioneOrdini.instance().visualizzaOrdini("daLuca", 3);
		assertEquals(2, result.size());
		
	}
	
	@Test
	public void test15() {
		
		Ristorante r = new Ristorante("daLuca", "", "", "", "", 0);
		LocalDate oData = LocalDate.of(2020, Month.MARCH, 1);
		Ordine o = new Ordine(r, new ArrayList<Pietanza>(), new ArrayList<Integer>(), oData);
		
		GestioneRistoranti.instance().aggiungiRistoratore("nomeRistoratore1", "cognomeRistoratore1",
				r.getNome(), r.getTelefono(), r.getEmail(), r.getCitt�(), r.getVia(), r.getCivico());
		
		GestioneOrdini.instance().aggiungiOrdine(o);
		
		ArrayList<Ordine> result = GestioneOrdini.instance().visualizzaOrdini("daLuca", 16);
		assertEquals(0, result.size());
		
	}
}
