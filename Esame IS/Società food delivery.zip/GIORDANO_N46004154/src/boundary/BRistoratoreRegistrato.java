package boundary;
import entity.Ristoratore;
import control.GestioneRistoranti;

public class BRistoratoreRegistrato {
	private Ristoratore utente;
	public BRistoratoreRegistrato(Ristoratore r) { utente = r; }
	
	public void aggiungiPietanza(String nome, String descrizione, Double prezzo) {
		GestioneRistoranti.instance().aggiungiPietanza(utente.getRistorante(),
				nome, descrizione, prezzo);
	}
	
	public boolean rimuoviPietanza(String nome) {
		return GestioneRistoranti.instance().rimuoviPietanza(utente.getRistorante(), nome);
	}
	
	public boolean modificaNomePietanza(String nome, String nuovoNome) {
		return GestioneRistoranti.instance().modificaNomePietanza(utente.getRistorante(),
				nome, nuovoNome);
	}
	
	public boolean modificaDescPietanza(String nome, String nuovoDesc) {
		return GestioneRistoranti.instance().modificaDescPietanza(utente.getRistorante(),
				nome, nuovoDesc);
	}
	
	public boolean modificaPrezzoPietanza(String nome, Double nuovoPrezzo) {
		return GestioneRistoranti.instance().modificaPrezzoPietanza(utente.getRistorante(),
				nome, nuovoPrezzo);
	}
}