package boundary;
import control.GestioneClienti;
import entity.Cliente;

public class BCliente {
	public BCliente() {}
	
	public Cliente registraCliente(String nome, String cognome, String telefono,
			String idCarta, Double saldoCarta) {
		return GestioneClienti.instance().registraCliente(nome, cognome, telefono, idCarta, saldoCarta);
	}
}
