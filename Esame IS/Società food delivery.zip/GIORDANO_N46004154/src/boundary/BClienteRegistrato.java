package boundary;
import entity.Cliente;
import entity.Ristorante;
import entity.Pietanza;
import control.GestioneOrdini;
import control.GestioneRistoranti;
import java.util.*;

public class BClienteRegistrato {
	private Cliente utente;
	public BClienteRegistrato(Cliente c) { utente = c; }
	
	public ArrayList<Ristorante> ricercaRistoranti(String citt�, String via, Integer civico) {
		return GestioneRistoranti.instance().ricercaRistoranti(citt�, via, civico);
	}
	
	public ArrayList<Pietanza> visualizzaPietanze(Ristorante ristorante) {
		return GestioneRistoranti.instance().visualizzaPietanze(ristorante);
	}
	
	public void selezionaRistorante(Ristorante r) {
		GestioneOrdini.instance().selezionaRistorante(r);
	}
	
	public void selezionaPietanze(Pietanza...pArr) {
		GestioneOrdini.instance().selezionaPietanze(pArr);
	}
	//	Ogni quantit� sar� assegnata alla pietanza di indice corrispondente
	public void selezionaQuantit�(Integer...iArr) {
		GestioneOrdini.instance().selezionaQuantit�(iArr);
	}
	
	public void annullaOrdine() {
		GestioneOrdini.instance().svuotaTemp();
	}
	
	public void confermaOrdine() {
		GestioneOrdini.instance().confermaOrdine(utente);
	}
}