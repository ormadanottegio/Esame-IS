package boundary;
import control.GestioneNotifiche;
import entity.Ristorante;
import entity.StatoOrdine;
import entity.Ordine;

public class BRider {
	BRider() {}
	
	public void iscriviti(Ristorante ristorante) {
		GestioneNotifiche.instance().iscriviBRider(ristorante, this);
	}
	public void update(Ordine ordine) {}
	public void ordineConsegnato(Ordine ordine) {
		GestioneNotifiche.instance().cambiaStatoOrdine(ordine, StatoOrdine.CONSEGNATO);
	}
}