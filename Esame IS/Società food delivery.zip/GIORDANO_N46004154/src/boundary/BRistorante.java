package boundary;
import control.GestioneNotifiche;
import entity.Ristorante;
import entity.Ordine;
import entity.StatoOrdine;

public class BRistorante {
	public BRistorante() {}
	
	public void iscriviti(Ristorante ristorante) {
		GestioneNotifiche.instance().iscriviBRistorante(ristorante, this);
	}
	
	public void update(Ordine ordine) {}
	
	public void ordinePronto(Ordine ordine) {
		GestioneNotifiche.instance().cambiaStatoOrdine(ordine, StatoOrdine.PRONTO);
	}
}
