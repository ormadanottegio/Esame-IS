package boundary;
import java.util.ArrayList;
import java.time.LocalDate;
import java.time.Month;
import control.GestioneRider;
import control.GestioneOrdini;
import entity.Ristorante;
import entity.Ordine;

public class BGestoreSistema {
	public BGestoreSistema() {}
	
	public void aggiungiRider(String nome, String cognome, String telefono) {
		GestioneRider.instance().aggiungiRider(nome, cognome, telefono);
	}
	
	public ArrayList<Ordine> generaReport(String nomeRistorante, Integer mese) {
		return GestioneOrdini.instance().visualizzaOrdini(nomeRistorante, mese);
	}
}
