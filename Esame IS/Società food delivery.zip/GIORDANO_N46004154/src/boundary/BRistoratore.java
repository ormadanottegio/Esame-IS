package boundary;
import control.GestioneRistoranti;
import entity.Ristoratore;

public class BRistoratore {
	public BRistoratore() {}
	public Ristoratore registraRistoratore(
			String nome, String cognome, String nomeRistorante,
			String telefonoRistorante, String emailRistorante, String citt�Ristorante,
			String viaRistorante, Integer civicoRistorante) {
		return GestioneRistoranti.instance().aggiungiRistoratore(
				nome, cognome, nomeRistorante,
				telefonoRistorante, emailRistorante, citt�Ristorante,
				viaRistorante, civicoRistorante
				);
	}
}
