package main;
import boundary.*;
import control.*;
import entity.*;

import java.time.LocalDate;
import java.time.Month;
import java.util.*;


public class Main {
	public static void main(String[] args) {
		//	CASO D'USO EFFETTUA ORDINE
		
		//	Creazione cliente e collegamento classe boundary
		BCliente bCliente = new BCliente();
		Cliente cliente = bCliente.registraCliente( "Mario", "Rossi", "0815961234", "007", 2000.0 );
		BClienteRegistrato bClienteRegistrato = new BClienteRegistrato(cliente);
		
		//	Creazione Ristoratore e Ristorante e collegamento classe boundary
		BRistoratore bRistoratore = new BRistoratore();
		Ristoratore ristoratore = bRistoratore.registraRistoratore( "Gianni", "Screzi",
				"Rosso Pomodoro", "0815431199", "screzigianni@gmail.com",
				"Napoli", "via dei gatti", 12 );
		BRistoratoreRegistrato bRistoratoreRegistrato = new BRistoratoreRegistrato(ristoratore);
		
		//	Aggiunta pietanze al ristorante
		bRistoratoreRegistrato.aggiungiPietanza( "Margherita", "classica", 3.50 );
		bRistoratoreRegistrato.aggiungiPietanza( "Fiocco", "crocch� e cotto", 4.50 );
		bRistoratoreRegistrato.aggiungiPietanza( "Ripieno", "Ricotta e pancetta", 5.0 );
		
		//	Registrazione per notifiche
		BRistorante bRistorante = new BRistorante();
		bRistorante.iscriviti(ristoratore.getRistorante());
		
		//	Simulazione creazione ordine
		ArrayList<Ristorante> ristorantiTrovati = 
				bClienteRegistrato.ricercaRistoranti( "Napoli", "via dei gatti", 12 );
		System.out.println( "Ristoranti trovati: " + ristorantiTrovati );
		bClienteRegistrato.selezionaRistorante( ristorantiTrovati.get(0) );
		
		ArrayList<Pietanza> pietanzeDisponibili = 
				bClienteRegistrato.visualizzaPietanze( ristorantiTrovati.get(0) );
		System.out.println( "Pietanze disponibili: " + pietanzeDisponibili );
		bClienteRegistrato.selezionaPietanze( pietanzeDisponibili.get(0), pietanzeDisponibili.get(2) );
		bClienteRegistrato.selezionaQuantit�( 2, 4 );
		
		bClienteRegistrato.confermaOrdine();
		//	Fine caso d'uso
//		
//		
//		//	Visualizzazione ordine
//		BGestoreSistema g = new BGestoreSistema();
//		System.out.println( "Ordini: " + g.generaReport("Rosso Pomodoro", null) );
	}

}
