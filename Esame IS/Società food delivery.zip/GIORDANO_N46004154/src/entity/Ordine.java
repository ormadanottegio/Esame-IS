package entity;
import java.time.LocalDate;
import java.util.ArrayList;
import control.GestioneNotifiche;

public class Ordine {
	private static long contatore = 0;
	private final long codice = contatore++;
	private StatoOrdine stato;
	private LocalDate data;
	private Double prezzo;
	private Ristorante mittente;
	private ArrayList<Porzione> porzioni = new ArrayList<Porzione>();
	
	public Ordine(Ristorante mittente, ArrayList<Pietanza> pietanze, ArrayList<Integer> quantit�, LocalDate data) {
		this.data = data;
		this.mittente = mittente;
		setStato(StatoOrdine.ATTESA_CONFERMA);
		for (int i = 0; i < pietanze.size(); i++)
			aggiungiPorzione(pietanze.get(i), quantit�.get(i));
		calcolaPrezzo();
	}
	
	public Ordine(Ristorante mittente, ArrayList<Pietanza> pietanze, ArrayList<Integer> quantit�) {
		data = LocalDate.now();
		this.mittente = mittente;
		setStato(StatoOrdine.ATTESA_CONFERMA);
		for (int i = 0; i < pietanze.size(); i++)
			aggiungiPorzione(pietanze.get(i), quantit�.get(i));
		calcolaPrezzo();
	}
	
	public long getCodice() { return codice; }
	public LocalDate getData() { return data; }
	public void calcolaPrezzo() {
		prezzo = 0.0;
		for (Porzione p : porzioni)
			prezzo += p.getTipoPorzione().getPrezzo() * p.getNumero();
	}
	public Double getPrezzo() { return prezzo; }
	private void aggiungiPorzione(Pietanza pietanza, Integer numero) {
		porzioni.add(new Porzione(pietanza, numero));
	}
	public ArrayList<Porzione> getPorzioni() { return porzioni; }
	public Ristorante getRistorante() { return mittente; }
	
	public void setStato(StatoOrdine stato) {
		this.stato = stato;
		GestioneNotifiche.instance().notifica(mittente, this);
	}
	public StatoOrdine getStato() { return stato; }

	public String toString() {
		return getCodice() + " " +  getData() + " " + getRistorante().getNome()
				+ " �" + getPrezzo() + " (" + getStato() + ")";
	}
}
