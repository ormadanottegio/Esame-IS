package entity;

public class Pietanza {
	private String nome;
	private String descrizione;
	private Double prezzo;
	public Pietanza(String nome, String descrizione, Double prezzo) {
		this.nome = nome;
		this.descrizione = descrizione;
		this.prezzo = prezzo;
	}
	
	public void setNome(String nome) { this.nome = nome; }
	public String getNome() { return nome; }
	public void setDescrizione(String descrizione) { this.descrizione = descrizione; }
	public String getDescrizione() { return descrizione; }
	public void setPrezzo(Double prezzo) { this.prezzo = prezzo; }
	public Double getPrezzo() { return prezzo; }
	
	public String toString() { 
		return getNome() + " �" + getPrezzo() + " (" + getDescrizione() + ")";
	}
}
