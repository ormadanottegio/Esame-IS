package entity;

public class Cliente {
	String nome;
	String cognome;
	String telefono;
	CartaDiCredito carta;
	
	public Cliente(String nome, String cognome, String telefono,
			String idCarta, Double saldoCarta) {
		this.nome = nome;
		this.cognome = cognome;
		this.telefono = telefono;
		carta = new CartaDiCredito(idCarta, saldoCarta);
	}
	
	public void setNome(String nome) { this.nome = nome; }
	public String getNome() { return nome; }
	public void setCognome(String cognome) { this.cognome = cognome; }
	public String getCognome() { return cognome; }
	public void setTelefono(String telefono) { this.telefono = telefono; }
	public String getTelefono() { return telefono; }
	public CartaDiCredito getCarta() { return carta; }
}
