package entity;

public class CartaDiCredito {
	private String id;
	private Double saldo;
	
	public boolean addToSaldo(Double amount) {	//	meglio con eccezioni
		if (amount < 0 && -amount > saldo)
			return false;
		saldo += amount;
		return true;
	}
	public void setSaldo(Double saldo) { this.saldo = saldo; }
	public Double getSaldo() { return saldo; }
	public void setId(String id) { this.id = id; }
	public String getId() { return id; }
	
	public CartaDiCredito(String id, Double saldo) {
		setId(id);
		setSaldo(saldo);
	}
}
