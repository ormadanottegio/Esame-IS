package entity;

public enum StatoOrdine {
	ATTESA_CONFERMA, CONFERMATO, PRONTO, CONSEGNATO;
}
