package entity;

public class Porzione {
	private Pietanza tipoPorzione;
	private Integer numeroElementi;
	
	public Porzione(Pietanza p, Integer n) {
		tipoPorzione = p;
		numeroElementi = n;
	}
	
	public void setTipoPorzione(Pietanza p) { tipoPorzione = p; }
	public Pietanza getTipoPorzione() { return tipoPorzione; }
	public void setNumero(Integer n) { numeroElementi = n; }
	public Integer getNumero() { return numeroElementi; }
}
