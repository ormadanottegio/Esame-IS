package entity;
import java.util.ArrayList;

public class Ristorante {
	private String nome;
	private String telefono;
	private String email;
	private String citt�;
	private String via;
	private Integer civico;
	private ArrayList<Pietanza> listaPietanze = new ArrayList<Pietanza>();
	
	public Ristorante(String nome, String telefono, String email, String citt�,
			String via, Integer civico) {
		this.nome = nome;
		this.telefono = telefono;
		this.email = email;
		this.citt� = citt�;
		this.via = via;
		this.civico = civico;
	}
	
	public void setNome(String n) { nome = n; }
	public String getNome() { return nome; }
	public void setTelefono(String t) { telefono = t; }
	public String getTelefono() { return telefono; }
	public void setEmail(String e) { email = e; }
	public String getEmail() { return email; }
	public void setCitt�(String c) { citt� = c; }
	public String getCitt�() { return citt�; }
	public void setVia(String v) { via = v; }
	public String getVia() { return via; }
	public void setCivico(Integer c) { civico = c; }
	public Integer getCivico() { return civico; }
	public ArrayList<Pietanza> getPietanze() { return listaPietanze; }
	public void aggiungiPietanza(String nome, String descrizione, Double prezzo) {
		listaPietanze.add(new Pietanza(nome, descrizione, prezzo));
	}
	
	//	Funzionano solo se ogni pietanza ha un nome diverso
	public boolean rimuoviPietanza(String nome) {
		for (Pietanza p : listaPietanze)
			if (p.getNome() == nome) {
				listaPietanze.remove(p);
				return true;
			}
		return false;	
	}
	public boolean modificaNomePietanza(String nome, String nuovoNome) {
		for (Pietanza p : listaPietanze)
			if (p.getNome() == nome) {
				p.setNome(nuovoNome);
				return true;
			}
		return false;
	}
	public boolean modificaDescPietanza(String nome, String nuovoDesc) {
		for (Pietanza p : listaPietanze)
			if (p.getNome() == nome) {
				p.setDescrizione(nuovoDesc);
				return true;
			}
		return false;
	}
	public boolean modificaPrezzoPietanza(String nome, Double nuovoPrezzo) {
		for (Pietanza p : listaPietanze)
			if (p.getNome() == nome) {
				p.setPrezzo(nuovoPrezzo);
				return true;
			}
		return false;
	}
	
	public String toString() {
		return getNome() + " " + getTelefono() + " " + getEmail() 
		+ " " + getCitt�() + " " + getVia() + " " + getCivico();
	}
}
