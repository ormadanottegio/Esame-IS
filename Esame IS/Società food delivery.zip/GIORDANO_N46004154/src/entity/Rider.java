package entity;

public class Rider {
	private String nome;
	private String cognome;
	private String telefono;
	public Rider(String nome, String cognome, String telefono) {
		setNome(nome);
		setCognome(cognome);
		setTelefono(telefono);
	}
	
	public void setNome(String nome) { this.nome = nome; }
	public String getNome() { return nome; }
	public void setCognome(String cognome) { this.cognome = cognome; }
	public String getCognome() { return cognome; }
	public void setTelefono(String telefono) { this.telefono = telefono; }
	public String getTelefono() { return telefono; }
}
