package entity;

public class Ristoratore {
	private String nome;
	private String cognome;
	private Ristorante ristorante;
	
	public Ristoratore(String nome, String cognome, Ristorante ristorante) {
		this.nome = nome;
		this.cognome = cognome;
		this.ristorante = ristorante;
	}
	
	public void setNome(String nome) { this.nome = nome; }
	public String getNome() { return nome; }
	public void setCognome(String cognome) { this.cognome = cognome; }
	public String getCognome() { return cognome; }
	public Ristorante getRistorante() { return ristorante; }
}
